-- INSTALLATION --

Enable the module like any other Drupal Module /admin/modules


-- CONFIGURATION --

1. Go to admin/config/media/views_foundation and configure path to Foundation
JavaScripts directory.

2. Add a view and specify the fields you want to output.

3. Activate the style plugin in the view > format > format (and/or
view > format > show), and chose "Foundation (plugin type)".

4. Change the Foundation plugin settings according to your needs.


-- REQUIREMENTS --

* Views Module installed.
* Theme with Zurb Foundation Framework.
