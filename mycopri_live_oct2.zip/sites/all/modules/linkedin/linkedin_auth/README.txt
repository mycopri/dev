=== LINKEDIN INTEGRATION ===

Maintainers:  Pascal Morin (bellesmanieres) Greg Harvey (greg.harvey) David
Landry (davad) Kyle Mathews (kyle_mathews)

see http://drupal.org/node/919550

/*********************************************
Installation/initial configuration

   See http://drupal.org/node/919412.


/*********************************************
Configuration/Usage

After enabling the module, go to admin/settings/linkedin. You can enable/disable
Status Update availability per content type, for comments (and event sign-ups if
you use the module.) For each, you can also specify a default message that will
be posted (and use placeholders for node title, url) Don't forget to set the
permissions for users accordingly.  Users have to link their LinkedIn account to
their local Drupal account from their preferences at user/%user/edit/linkedin.
Beware, text is limited to 140 characters
