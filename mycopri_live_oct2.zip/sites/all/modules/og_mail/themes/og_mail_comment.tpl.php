<?php

/*
 * Text for new post in a group
 * 
 * Available variables is $node, $group
 * 
 */
?>
<?php print "$comment_author $comment_link on $post in $group $comment_time." ?>