<?php
/**
 * @file
 * Default theme implementation for og content activity notification email.
 */
?>

<div>The MyCopri Team</div>