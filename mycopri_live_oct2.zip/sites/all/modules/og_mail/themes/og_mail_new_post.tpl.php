<?php
/**
 * @file
 * Default theme implementation for new posts in groups.
 *
 * Available variables:
 *    $post
 *    $group
 *    $author
 *    $time
 *
 * @see template_preprocess()
 * @see template_process()
 * @see og_mail_preprocess_updated_post()
 */
?>
<?php print "$author posted $post in $group $time." ?>